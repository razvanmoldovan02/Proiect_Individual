import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Profile extends JDialog {
    private JButton btnCommunity;
    private JButton btnStore;
    private JButton btnProfile;
    private JButton btnFriends;
    private JButton btnGames;
    private JLabel lbName;
    private JButton friendRequestsButton;
    private JPanel N;
    private JPanel Profile;

    public Profile(User user) {
        setContentPane(Profile);
        setVisible(true);

        setMinimumSize(new Dimension(150, 154));
        setMinimumSize(new Dimension(450, 474));
        setSize(800, 800);
        setModal(true);
        setLocationRelativeTo(null);
        btnCommunity.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Community(user);
            }
        });
        friendRequestsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Friendrequest(user);
            }
        });
        btnProfile.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Profile(user);
            }
        });
        btnStore.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Store(user);
            }
        });
        btnFriends.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Friends(user);
            }
        });
        btnGames.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Mygames(user);
            }
        });
    }
}
