
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Community extends JDialog{
    private JPanel communityPanel;
    private JButton btnCommunity;
    private JButton btnStore;
    private JButton btnProfile;
    private JLabel lbName;
    private JTextField tfFriends;
    private JButton btAdd;
    private JLabel lbFriends;
    private JButton btnSearch;

    public Community(User user) {
        //super(parent);
        btAdd.setVisible(false);
        System.out.print("ok");
        setVisible(true);
        setTitle("Community");
        setContentPane(communityPanel);
        setMinimumSize(new Dimension(450, 474));
        setSize(600, 600);
        setModal(true);
        setLocationRelativeTo(null);
        btnCommunity.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();new Community(user);
            }
        });
        btnProfile.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); new Profile(user);
            }
        });
        btnStore.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); new Store(user);
            }
        });
        btnSearch.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fname = tfFriends.getText();
                int ok = searchfriends(fname, user.name);
                if (ok == 0)
                    lbFriends.setText("user not found");
                else if (ok == 1) {
                    lbFriends.setText("user found");
                    btAdd.setVisible(true);
                } else if (ok == 2)
                    lbFriends.setText("You can't add this user as a friend");
            }
        });
        btAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fname = tfFriends.getText();
                addfriends(fname,user.name);
                btAdd.setVisible(false);
            }
        });

    }


    private int searchfriends(String fname,String uname) {
        if(fname.equals(uname))
            return 2;
        final String DB_URL = "jdbc:mysql://localhost/friendsof?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
        int ok=0;
        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            // Connected to database successfully...

            Statement stmt = conn.createStatement();
            try {
                ResultSet rs;
                rs = stmt.executeQuery( "SELECT * FROM "+fname);}
            catch(Exception e){
                return ok;
            }
                ok=1;
                ResultSet rs;
                rs = stmt.executeQuery("select * from "+uname+" where friendname='"+fname+"'");
                rs.next();
                try {
                rs.getString(1);
                    ok=2;}
                catch(Exception e){
                    return ok;
                }

            stmt.close();
            conn.close();

        }catch(Exception e){
            e.printStackTrace();
        }
        return ok;
    }
        private void addfriends(String fname,String uname) {
            final String DB_URL = "jdbc:mysql://localhost/friendsof?serverTimezone=UTC";
            final String USERNAME = "root";
            final String PASSWORD = "";
            int ok=0;
            try{
                Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                // Connected to database successfully...
                Statement stmt = conn.createStatement();
                String sql = "INSERT INTO "+uname+" (friendname,type) " +
                        "VALUES (?,?)";
                PreparedStatement preparedStatement = conn.prepareStatement(sql);
                preparedStatement.setString(1, fname);
                preparedStatement.setString(2, "receive request");
                preparedStatement.executeUpdate();

               sql = "INSERT INTO "+fname+" (friendname,type) " +
                        "VALUES (?,?)";
                 preparedStatement = conn.prepareStatement(sql);
                preparedStatement.setString(1, uname);
                preparedStatement.setString(2, "send request");
                preparedStatement.executeUpdate();

                stmt.close();
                conn.close();

            }catch(Exception e){
                e.printStackTrace();
            }
        }

}
