//package JavaDB_001;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;


public class Addgame extends JFrame{
    JButton button ;
    JButton button2;
    JLabel label;
    JTextField textPRICE;

    JTextField [] g;
    JTextField textAGE;
    JTextField textDEV;
    JTextField textNAME;
    JTextArea area;

    String s;

    public Addgame(){

        super("insert a game to database in java");
        setLocationRelativeTo(null);
        button = new JButton("ADD");
        button.setBounds(200,300,100,40);

        button2 = new JButton("Browse");
        button2.setBounds(80, 300, 100, 40);

        textPRICE = new JTextField("Price");
        textPRICE.setBounds(490,295,100,20);

        textDEV = new JTextField("Developer");
        textDEV.setBounds(350,325,100,20);

        textAGE = new JTextField("Age");
        textAGE.setBounds(490,325,100,20);

        textNAME = new JTextField("Name");
        textNAME.setBounds(350,295,100,20);


        label = new JLabel();
        label.setBounds(200,10,250,250);

        //button to browse the image into jlabel
        button2.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
                FileNameExtensionFilter filter = new FileNameExtensionFilter("*.IMAGE", "jpg","gif","png");
                fileChooser.addChoosableFileFilter(filter);
                int result = fileChooser.showSaveDialog(null);
                if(result == JFileChooser.APPROVE_OPTION){
                    File selectedFile = fileChooser.getSelectedFile();
                    String path = selectedFile.getAbsolutePath();
                    label.setIcon(ResizeImage(path));
                    s = path;
                }
                else if(result == JFileChooser.CANCEL_OPTION){
                    System.out.println("No Data");
                }
            }
        });

        //button to insert image and some data into mysql database
        button.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e){
                try{
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mystore","root","");
                    PreparedStatement ps = con.prepareStatement("insert into games(name,developer,age,price,image) values(?,?,?,?,?)");
                    InputStream is = new FileInputStream(new File(s));

                    ps.setString(1, textNAME.getText());
                    ps.setString(2, textDEV.getText());
                    ps.setString(3, textAGE.getText());
                    ps.setString(4, textPRICE.getText());
                    ps.setBlob(5,is);
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Data Inserted");
                }catch(Exception ex){
                    JOptionPane.showMessageDialog(null, "This game already exist");
                }
            }
        });

        add(label);
        add(textPRICE);
        add(textDEV);
        add(textAGE);
        add(textNAME);
        add(button);
        add(button2);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700,440);
        setVisible(true);
    }

    //Methode To Resize The ImageIcon
    public ImageIcon ResizeImage(String imgPath){
        ImageIcon MyImage = new ImageIcon(imgPath);
        Image img = MyImage.getImage();
        Image newImage = img.getScaledInstance(label.getWidth(), label.getHeight(),Image.SCALE_SMOOTH);
        ImageIcon image = new ImageIcon(newImage);
        return image;
    }

    public static void main(String[] args){
        new Addgame();

    }
}