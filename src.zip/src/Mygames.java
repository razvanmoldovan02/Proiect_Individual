
import javax.swing.*;
        import java.awt.*;
        import java.awt.event.ActionEvent;
        import java.awt.event.ActionListener;
        import java.sql.*;
        import java.util.ArrayList;
        import java.util.List;

public class Mygames extends JDialog{

    int k=0;
    private JPanel Mygames;
    private JPanel gamelabel;
    private JLabel lbImg;
    private JLabel lbGname;
    private JLabel lbDev;
    private JLabel lbPrice;
    private JLabel lbAge;
    private JButton playButton;
    private JButton removeButton;
    private JButton previousButton;
    private JButton nextButton;
    private JLabel lbName;
    private JLabel Gmoney;
    private JLabel nogameslb;

    public Mygames(User user)
    {
        setContentPane(Mygames);
        setVisible(true);

        setMinimumSize(new Dimension(450, 474));
        setSize(500, 500);
        setModal(true);
        setLocationRelativeTo(null);
        java.util.List<Games> l=new ArrayList<>();
        database(l,user.name);
        nogameslb.setVisible(false);
        Gmoney.setText("Gmoney: "+user.money);
        show(l);

        if(k==0)
            previousButton.setEnabled(false);
        if(k==l.size()-1)
            nextButton.setEnabled(false);
        nextButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                k++;
                show(l);
                if(k>=l.size()-1)
                    nextButton.setEnabled(false);
                if(k!=0)
                    previousButton.setEnabled(true);

            }
        });
        previousButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                k--;
                show(l);
                if(k==0)
                    previousButton.setEnabled(false);
                if(k!=l.size()-1)
                    nextButton.setEnabled(true);
            }
        });
        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                removegame(user.name,l.get(k).name);
                System.out.println(k);
                //database(l,user.name);
                l.remove(k);

                if(k!=0)
                    k--;
                if(k==0)
                    previousButton.setEnabled(false);
                if(k>=l.size()-1)
                    nextButton.setEnabled(false);
                show(l);
                System.out.println(k);
            }
        });
    }
    void show(java.util.List<Games> l)
    {   if(l.isEmpty()) {
        nogameslb.setVisible(true);
        nogameslb.setText("No games in the basket");
        gamelabel.setVisible(false);
        previousButton.setEnabled(false);
        nextButton.setEnabled(false);
    }
    /*if(l.size()==1)
    {
        previousButton.setEnabled(false);
        nextButton.setEnabled(false);
    }*/
    else {
        lbGname.setText("Name: " + l.get(k).name);
        lbDev.setText("Developer: " + l.get(k).dev);
        lbAge.setText("Minimum age: " + l.get(k).age);
        lbPrice.setText("Price: " + l.get(k).price + "$");
        try {
            int myblobLength = (int) l.get(k).Image.length();
            byte[] my = l.get(k).Image.getBytes(1, myblobLength);
            ImageIcon gg = new ImageIcon(my);
            lbImg.setIcon(gg);
        } catch (Exception ee) {
        }
    }
    }
    void database(List<Games> l, String uname)
    {   Games g = new Games();
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mystore","root","");
            Statement stmt = con.createStatement();
            //PreparedStatement ps = con.prepareStatement("select * from games");
            //InputStream is = new FileInputStream(new File(s));
            ResultSet rs;
            rs = stmt.executeQuery("select * from games");
            ResultSet rs1;
            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/mygames?serverTimezone=UTC","root","");
            Statement stmt1 = con1.createStatement();
            while(rs.next()) {
                g.name = rs.getString(1);
                g.dev = rs.getString(2);
                g.price = rs.getString(4);
                g.age = rs.getString(3);
                g.Image = rs.getBlob(5);
                rs1 = stmt1.executeQuery("select * from "+uname);
                while(rs1.next())
                    if (rs1.getString(1).equals(g.name))
                        if (rs1.getString(2).equals("bought"))
                            l.add(new Games(g.name, g.dev, g.age, g.price, g.Image));
            }

            stmt.close();
            con.close();
            stmt1.close();
            con1.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }

    }
    private void removegame(String uname,String game) {
        final String DB_URL = "jdbc:mysql://localhost/mygames?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
        int ok=0;
        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            // Connected to database successfully...
            Statement stmt = conn.createStatement();
            String sql = "delete from "+uname+" where gamename = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, game);
            preparedStatement.executeUpdate();


            stmt.close();
            conn.close();

        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public static void main(String[] args) {
        User user =new User();
        new Basket(user);
    } }


