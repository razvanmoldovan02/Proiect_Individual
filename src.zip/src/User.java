public class User {
    public String name;
    public String email;
    public String age;
    public String password;
    public String money;
}
