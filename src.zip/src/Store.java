import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Store extends JDialog{
    private JPanel mnlabel;
    private JPanel label1;
    private JButton btnCommunity;
    private JButton btnStore;
    private JButton btnProfile;
    private JLabel lbName;
    private JLabel lbGname;
    private JLabel lbDev;
    private JLabel lbPrice;
    private JLabel lbImg;
    private JButton addButton;
    private JButton previousButton;
    private JButton nextButton;
    private JLabel lbAge;
    private JButton btnBasket;
    private JPanel Store;
    private JPanel gamelabel;
    int k=0;
    public Store(User user) {
        setContentPane(Store);
        setVisible(true);

        setMinimumSize(new Dimension(150, 154));
        setMinimumSize(new Dimension(450, 474));
        setSize(800, 800);
        setModal(true);
        setLocationRelativeTo(null);
        btnCommunity.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();new Community(user);
            }
        });
        btnBasket.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Basket(user);
            }
        });

        btnProfile.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); new Profile(user);
            }
        });
        btnStore.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); new Store(user);
            }
        });
        List<Games> l=new ArrayList<>();
        database(l);
        show(l);
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                addgame(user.name,l.get(k).name);

            }
        });
        if(k==0)
            previousButton.setEnabled(false);
        if(k==l.size()-1)
            nextButton.setEnabled(false);
        nextButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                k++;
                show(l);
                if(k==l.size()-1)
                    nextButton.setEnabled(false);
                if(k!=0)
                    previousButton.setEnabled(true);

            }
        });
        previousButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                k--;
                show(l);
                if(k==0)
                    previousButton.setEnabled(false);
                if(k!=l.size()-1)
                    nextButton.setEnabled(true);
            }
        });
    }

    void show(List<Games> l)
    {
        lbGname.setText("Name: " + l.get(k).name);
        lbDev.setText("Developer: " + l.get(k).dev);
        lbAge.setText("Minimum age: " + l.get(k).age);
        lbPrice.setText("Price: " + l.get(k).price+"$");
        try {
            int myblobLength = (int) l.get(k).Image.length();
            byte[] my = l.get(k).Image.getBytes(1, myblobLength);
            ImageIcon gg = new ImageIcon(my);
            lbImg.setIcon(gg);
        }
        catch(Exception ee)
        {}

    }
    void database(List l)
    {   Games g = new Games();
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mystore","root","");
            Statement stmt = con.createStatement();
            //PreparedStatement ps = con.prepareStatement("select * from games");
            //InputStream is = new FileInputStream(new File(s));
            ResultSet rs;
            rs = stmt.executeQuery("select * from games");
            while(rs.next()) {
                g.name = rs.getString(1);
                g.dev = rs.getString(2);
                g.price = rs.getString(4);
                g.age = rs.getString(3);
                g.Image = rs.getBlob(5);
                l.add(new Games(g.name,g.dev,g.age,g.price,g.Image));
            }
            //System.out.print(g);
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    private void addgame(String uname,String game) {
        final String DB_URL = "jdbc:mysql://localhost/mygames?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "";
        int ok=0;
        try{
            Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            // Connected to database successfully...
            Statement stmt = conn.createStatement();
            String sql = "INSERT INTO "+uname+" (gamename,type) " +
                    "VALUES (?,?)";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, game);
            String b="basket";
            preparedStatement.setString(2, b);
            preparedStatement.executeUpdate();


            stmt.close();
            conn.close();
            JOptionPane.showMessageDialog(this,
                    "Game added to the basket",
                    "Error",
                    JOptionPane.INFORMATION_MESSAGE);
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,
                    "You can't add this game to the basket",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

    }
    public static void main(String[] args) {
        User user =new User();
        new Store(user);
    } }